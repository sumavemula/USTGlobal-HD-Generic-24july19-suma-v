import {  Component } from '@angular/core';
@Component({
    selector : 'app-sample',
    template : `
    <h1>sample componenet is working</h1>
    `,
})
export class SampleComponent{

}