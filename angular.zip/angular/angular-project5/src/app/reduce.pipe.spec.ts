import { ReducePipe } from './reduce.pipe';

describe('ReducePipe', () => {
  it('create an instance', () => {
    const pipe = new ReducePipe();
    expect(pipe).toBeTruthy();
  });
});
