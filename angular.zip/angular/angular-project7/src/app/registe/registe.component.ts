import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registe',
  templateUrl: './registe.component.html',
  styleUrls: ['./registe.component.css']
})
export class RegisteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
